from datetime import datetime, timezone
import time
from functools import wraps

class Vtime:
    # UTC 协调世界时
    @staticmethod
    def get_utctime():
        gt = datetime.now(timezone.utc).strftime("%H:%M:%S")
        return gt
    @staticmethod
    def get_utcdate():  
        gt = datetime.now(timezone.utc).strftime("%Y-%m-%d")  
        return gt
    @staticmethod
    def utctimestamp():
        result = datetime.now(timezone.utc).timestamp()
        return result
    @staticmethod
    def utctimestamp_to_datetime(ts):
        return datetime.fromtimestamp(ts, timezone.utc)

    # Loc
    @staticmethod
    def get_time():
        gt = datetime.now().strftime("%H:%M:%S")
        return gt
    @staticmethod
    def get_date():
        gt = datetime.now().strftime("%Y-%m-%d")
        return gt
    @staticmethod
    def timestamp(tg :str = None):
        if tg == None:
            result = int(datetime.now().timestamp())
        else:
            try:
                result = int(datetime.strptime(tg, '%Y-%m-%d %H:%M').timestamp())
            except:
                return 'error'
        return result
    @staticmethod
    def timestamp_to_datetime(ts):
        return datetime.fromtimestamp(ts)

    # TimeCalculation
    @staticmethod
    def time_difference(timestamp1: int, timestamp2: int):
        try:
            tf = timestamp2 - timestamp1
            days = tf / 3600 / 24
            hours = tf / 3600
            minutes = tf / 60
            seconds = tf
            tfm = {
                'd': days,
                'h': hours,
                'm': minutes,
                's': seconds
            }
            return tfm
        except Exception as e:
            return e

    @staticmethod
    def timeit(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            end_time = time.time()
            elapsed_time = end_time - start_time
            print(f"{func.__name__} executed {elapsed_time:.0f} seconds")
            return result
        return wrapper