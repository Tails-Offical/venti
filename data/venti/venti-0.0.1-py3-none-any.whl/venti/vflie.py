import hashlib

class Vfile:
    @staticmethod
    def file_to_binary(file_path, chunk_size=1024):
        try:
            with open(file_path, 'rb') as f:
                while chunk := f.read(chunk_size):
                    yield chunk
        except Exception as e:
            return e

    @staticmethod
    def binary_to_file(binary_data, file_path):
        try:
            with open(file_path, 'wb') as f:
                for chunk in binary_data:
                    f.write(chunk)
        except Exception as e:
            return e

    @staticmethod
    def file_sha256(file_path):
        try:
            with open(file_path,"rb") as f:
                bytes = f.read()
                readable_hash = hashlib.sha256(bytes).hexdigest()
                return readable_hash
        except Exception as e:
            return e
