import qrcode
from barcode import EAN13
from barcode.writer import ImageWriter

class VCode:
    @staticmethod
    def qrcode_character(qr_data):
        try:
            qr = qrcode.QRCode(version=1,
                                error_correction=qrcode.constants.ERROR_CORRECT_L,
                                box_size=10,
                                border=1)
            qr.add_data(qr_data)
            qr.make()
            qr.print_ascii()
        except Exception as e:
            return e

    @staticmethod
    def qrcode_picture(qr_data, ver=1, box_size=10, border=4):
        try:
            qr = qrcode.QRCode(
                version=ver,
                error_correction=qrcode.constants.ERROR_CORRECT_H,
                box_size=box_size,
                border=border,
            )
            qr.add_data(qr_data)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white")
            img.save('qrcode.png')
        except Exception as e:
            return e

    @staticmethod
    def barcode_picture(bar_data):
        try:
            ean = EAN13(bar_data, writer=ImageWriter())
            ean.save('barcode')
        except Exception as e:
            return e
