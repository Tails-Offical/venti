import hashlib
from cryptography.fernet import Fernet

class Vstr:
    @staticmethod
    def str_hash(string):
        try:
            message = string.encode()
            return hashlib.sha256(message).hexdigest()
        except Exception as e:
            return e

    @staticmethod
    def str_encryption(text):
        try:
            key = Fernet.generate_key()
            cipherSuite = Fernet(key)
            encrypted_text = cipherSuite.encrypt(text.encode())
            result = {"str":encrypted_text,"key":key}
            return result
        except Exception as e:
            return e

    @staticmethod
    def str_decrypt(text, key):
        try:
            cipherSuite = Fernet(key)
            decryptedText = cipherSuite.decrypt(text)
            return decryptedText.decode()
        except Exception as e:
            return e

    @staticmethod
    def str_to_binary(string):
        try:
            result = string.encode('utf-8')
            return result
        except Exception as e:
            return e

    @staticmethod
    def binary_to_str(binary):
        try:
            result = binary.decode('utf-8')
            return result
        except Exception as e:
            return e
