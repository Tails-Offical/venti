import logging

class CustomLogger(logging.Logger):
    def venti(self, message, *args, **kwargs):
        if self.isEnabledFor(21):
            self._log(21, message, args, **kwargs)  # 使用21作为日志等级

class Vlog:
    def __init__(self, log_file):
        self.log_file = log_file

    def logger(self, venti):
        try:
            logging.addLevelName(21, "VENTI")
            
            # 使用自定义的Logger类
            logging.setLoggerClass(venti)
            logger = logging.getLogger(__name__)
            logger.setLevel(21)
            
            # 日志格式
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            
            # 文件处理器
            # file_handler = logging.FileHandler(self.log_file, mode='w', encoding='utf-8', delay=False)
            file_handler = logging.FileHandler(self.log_file, mode='a', encoding='utf-8', delay=False)
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
            
            # 控制台处理器
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)
            
            return logger
        except Exception as e:
            return e
